"use strict";

let fs = require("fs");
let path = require("path");

let dir = "eg";
let programs = require("./tpl/programs.json");
let files = programs.reduce((accum, entry) => {
  return accum.concat(entry.examples.map(eg => eg.file));
}, []);

files.forEach(file => {
  let source = fs.readFileSync(`./eg/${file}`, "utf8");

  if (/@markdown/.test(source)) {
    let lines = source.split("\n");
    let inMarkdown = false;

    lines.forEach((line, index) => {
      if (/@markdown/.test(line)) {
        inMarkdown = !inMarkdown;

        if (inMarkdown) {
          lines[index] = '/* @markdown';
        } else {
          lines[index] = '@markdown */';
        }
      } else {
        if (inMarkdown) {
          line = line.trim();
          if (line) {
            lines[index] = line.replace(/^\/\//, "").trim();
            // markdown.push(
            //   line.replace(/^\/\//, "").trim()
            // );
          }
        }
      }
    });

    console.log(lines.join("\n"));

    fs.writeFileSync(`./eg/${file}`, lines.join("\n"), "utf8");
  }
});
