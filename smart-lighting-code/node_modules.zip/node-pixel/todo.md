# Current tasks

**Version:** `0.4.1`

> Library for controlling addressable LEDs (such as NeoPixels) from firmata or Johnny Five.

* * *

## TODO

## firmware/src/README.md

-  **TODO** `(line 56)` 

## firmware/src/controller_src/firmata/node_pixel_firmata.ino

-  **TODO** `(line 29)` : use Program Control to load stored profiles from EEPROM
-  **TODO** `(line 302)` : put error msgs in EEPROM
-  **TODO** `(line 304)` : save status to EEPROM here, if changed
-  **TODO** `(line 368)` : save status to EEPROM here, if changed
-  **TODO** `(line 630)` : option to load config from EEPROM instead of default
-  **TODO** `(line 663)` : this can never execute, since no pins default to digital input

## firmware/src/libs/lightws2812/lw_ws2812.h

-  **TODO** `(line 34)`  get this to work in setup

## lib/pixel.js

-  **TODO** `(line 3)` :


* * *

Last generated: Wed Dec 09 2015 00:18:01 by [grunt-todo](https://github.com/leny/grunt-todo).
