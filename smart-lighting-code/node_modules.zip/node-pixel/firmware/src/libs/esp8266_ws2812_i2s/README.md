# esp8266_ws2812_i2s
ESP8266 Library for driving WS2812 led-strip using the I2S output. Use within the Arduino IDE
