// Base include for all the main things we need to set up.
#include <stdint.h>

typedef int receiveint;

#define DEBUG false
#define DEBUG_I2C false
