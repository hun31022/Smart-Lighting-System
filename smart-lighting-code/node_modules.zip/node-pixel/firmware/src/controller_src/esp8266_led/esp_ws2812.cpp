#include "esp_ws2812.h"
#include <stdlib.h>
#include "./esp_ws2812_defs.h"
#include "./esp_ws2812_dma.h"

extern "C"
{
#include "./esp_ws2812_dma.h"
};

WS2812::WS2812(uint16_t num_leds, uint16_t offset) {
    // used if we know the length of the strip and
    // the offset from the start of the master array
    // up front
    init(num_leds, offset);
}

WS2812::WS2812(uint16_t num_leds) {
    // used when we know the lengths up front.
    init(num_leds);
}

WS2812::WS2812() {
    // used as an empty constructor for setup.
    init(0);
}

void WS2812::init(uint16_t num_leds, uint16_t offset) {

    set_length(num_leds);
    set_offset(offset);

  uint8_t i;
  uint16_t j;

  Serial.print("N_PIXEL_WORDS: ");
  Serial.println(NUM_I2S_PIXEL_WORDS);

  // clear zero buffer
  for(j=0; j<NUM_I2S_ZERO_WORDS; j++)
  {
    i2s_zeros_buffer[j] = 0;
  }

  // do memory allocation for i2s buffer(s)
  for(i=0; i<WS2812_DITHER_NUM; i++)
  {
    i2s_pixels_buffer[i] = new uint32_t[NUM_I2S_PIXEL_WORDS];

    // TODO : handle memory allocation error better
    if (i2s_pixels_buffer[i] == 0)
    {
      Serial.println("WS2812_I2S : ERROR ALLOCATING MEMORY");
      return;
    }

    for(j=0; j<NUM_I2S_PIXEL_WORDS; j++)
    {
      i2s_pixels_buffer[i][j] = 0;
    }
  }

  // set-up DMA descriptors / 1 pair per dither-factor
  for(i=0; i<WS2812_DITHER_NUM; i++)
  {
    i2s_pixels_queue[i].owner     = 1;
    i2s_pixels_queue[i].eof       = 1;
    i2s_pixels_queue[i].sub_sof   = 0;
    i2s_pixels_queue[i].datalen   = NUM_I2S_PIXEL_BYTES;     // Size in bytes
    i2s_pixels_queue[i].blocksize = NUM_I2S_PIXEL_BYTES;     // Size in bytes
    i2s_pixels_queue[i].buf_ptr   = (uint32_t)i2s_pixels_buffer[i];
    i2s_pixels_queue[i].unused    = 0;
    i2s_pixels_queue[i].next_link_ptr = (uint32_t)&i2s_zeros_queue[i];  // always link to zeros-buffer

    i2s_zeros_queue[i].owner      = 1;
    i2s_zeros_queue[i].eof        = 1;
    i2s_zeros_queue[i].sub_sof    = 0;
    i2s_zeros_queue[i].datalen    = NUM_I2S_ZERO_BYTES;      // Size in bytes)
    i2s_zeros_queue[i].blocksize  = NUM_I2S_ZERO_BYTES;      // Size in bytes
    i2s_zeros_queue[i].buf_ptr    = (uint32_t)i2s_zeros_buffer;
    i2s_zeros_queue[i].unused     = 0;

    if (i == (WS2812_DITHER_NUM-1)) // last DMA descriptor in linked list ?
    {
      // yes : link to first DMA descriptor
      i2s_zeros_queue[i].next_link_ptr = (uint32_t)&i2s_pixels_queue[0];
    }
    else
    {
      // no : link to next DMA descriptor
      i2s_zeros_queue[i].next_link_ptr = (uint32_t)&i2s_pixels_queue[i+1];
    }
  }

  // call C based helper function
  // I did not really succeed in putting the code from the helper
  // funtion directly into this constructor...has something to do
  // with  C vs. C++
  // the i2c_writeReg_Mask macro (+ others) failed.. see ws2812_defs.h
  // may be I solve this later

  // parameter = first entry in DMA descriptor list, i.e the descriptor list
  ws2812_dma(i2s_pixels_queue);

}

void WS2812::init(uint16_t num_leds) {
    // assume offset is zeron in this case
    init(num_leds, 0);
}

void WS2812::set_offset(uint16_t master_offset) {
    offset = master_offset;
}

void WS2812::set_length(uint16_t num_leds) {
    count_led = num_leds;
}

uint16_t WS2812::get_length() {
    return count_led;
}

// TODO: Remove magic threes
void WS2812::sync(uint8_t *px_array, uint8_t pixel_depth) {
    Serial.println("Sending pixel data to strip");
	/***ws2812_port_reg |= pinMask; // Enable DDR
	ws2812_sendarray_mask(px_array+(offset*pixel_depth),
            count_led * pixel_depth,
            pinMask,(uint8_t*) ws2812_port,(uint8_t*) ws2812_port_reg
    );**/
}

// Send out WS2812 bits with coded pulses, one nibble, then the other.
static const uint16_t bitpatterns[16] =
{
  0b1000100010001000, 0b1000100010001110, 0b1000100011101000, 0b1000100011101110,
  0b1000111010001000, 0b1000111010001110, 0b1000111011101000, 0b1000111011101110,
  0b1110100010001000, 0b1110100010001110, 0b1110100011101000, 0b1110100011101110,
  0b1110111010001000, 0b1110111010001110, 0b1110111011101000, 0b1110111011101110,
};

// display the pixels
void WS2812::show(uint8_t *pixels)
{
  uint8_t *buffer;
  uint8_t pixelbyte;
  uint16_t b;
  uint16_t *i2s_ptr[WS2812_DITHER_NUM];

  buffer = (uint8_t *)pixels;

  // set-up pointers into the i2s-pixel-buffers
  //for(i=0; i<WS2812_DITHER_NUM; i++)
  //{
    i2s_ptr[0] = (uint16_t *)i2s_pixels_buffer[0];
  //}

  // for every pixel in the input-array
  // - get the pixel value (either R,G, or B)
  // - for every dithered buffer
  //   get the gamma-corrected output value
  // - and transform into i2s nibble

    Serial.println("In show");
    Serial.print("count led: ");
    Serial.println(count_led);
  for(b=0; b<(count_led * 3); b++)
  {
    pixelbyte = *buffer++;

    //for(i=0; i<WS2812_DITHER_NUM; i++)
    //{
    //
    Serial.print(b);
    Serial.print(": ");
    Serial.print(pixelbyte);
    Serial.print(" ");
    Serial.println();

//    Serial.print( bitpatterns[ (pixelbyte & 0x0f) ], BIN );
//      *(i2s_ptr[0]++) = bitpatterns[ (pixelbyte >> 4) & 0x0f ];


//      *(i2s_ptr[0]++) = bitpatterns[ (pixelbyte & 0x0f) ];
//      *(i2s_ptr[0]++) = bitpatterns[ (pixelbyte >> 4) & 0x0f ];
    //}
  }

}


WS2812::~WS2812() {
}

void WS2812::setOutput(uint8_t pin) {
    // noop
    ;
}
