// This example shows how to use node-pixel using Johnny Five as the
// hook for the board.
var five = require("johnny-five");
var pixel = require("../lib/pixel.js");

var opts = {};
opts.port = process.argv[2] || "";

var board = new five.Board(opts);
var strip = null;

var fps = 50; // how many frames per second do you want to try?

board.on("ready", function() {

    console.log("Board ready, lets add light");

    strip = new pixel.Strip({
        color_order: pixel.COLOR_ORDER.GRB,
        board: this,
        controller: "I2CBACKPACK",
        strips: [24*15],
    });

    strip.on("ready", function() {

        console.log("Strip ready, let's go");

        var colors = ["red", "green", "blue", "yellow", "cyan", "magenta", "white"];
        var current_colors = [
            0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4,
            0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4,
            0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4,
        ];
        var current_pos = [
            0,1,2,3,4, 30,31,32,33,34, 60,61,62,63,64, 90,91,92,93,94,
            120,121,122,123,124, 150,151,152,153,154, 180,181,182,183,184,
            210,211,212,213,214, 240,241,242,243,244, 270,271,272,273,274,
            300,301,302,303,304, 330,331,332,333,334,
        ];
        var blinker = setInterval(function() {

            strip.color("#000"); // blanks it out

            for (var i=0; i< current_pos.length; i++) {
                if (++current_pos[i] >= strip.stripLength()) {
                    current_pos[i] = 0;
                    if (++current_colors[i] >= colors.length) current_colors[i] = 0;
                }
                strip.pixel(current_pos[i]).color(colors[current_colors[i]]);
            }

            strip.show();
        }, 1000/fps);
    });
});
