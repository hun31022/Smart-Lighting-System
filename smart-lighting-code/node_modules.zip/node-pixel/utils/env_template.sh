#! /bin/sh

# this is a template for setting the environment variables you need for things
# like building etc so grunt can do what it needs to do if needed.

export ARDUINO_PATH=~/Downloads/arduino.app/Contents/MacOS/Arduino

